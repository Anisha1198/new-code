
package org.openweathermap;

import io.micronaut.core.annotation.Introspected;

@Introspected
public class Rain {
    private Integer lastThreeHours;

    public Rain() {
    }

    public Integer getLastThreeHours() {
        return lastThreeHours;
    }

    public void setLastThreeHours(Integer lastThreeHours) {
        this.lastThreeHours = lastThreeHours;
    }

}
