package weather

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
