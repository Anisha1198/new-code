package weather

import groovy.transform.CompileStatic
import org.openweathermap.CurrentWeather
import openweathermap.OpenweathermapService
import org.openweathermap.Unit

@CompileStatic
class HomeController {
    openweathermap.OpenweathermapService openweathermapService

    def index(String unit) {
        Unit unitEnum = Unit.unitWithString(unit)
        CurrentWeather currentWeather = openweathermapService.currentWeather(unitEnum)
        [currentWeather: currentWeather, unit: unitEnum]
    }
}
